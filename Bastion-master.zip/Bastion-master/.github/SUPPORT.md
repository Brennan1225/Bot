  If you need help with installing, updating, configuring or using Bastion then
  please head over to the [Bastion HQ](https://discord.gg/fzx8fkt 'Bastion HQ')
  and our awesome support staff will help you out with best of their knowledge.
