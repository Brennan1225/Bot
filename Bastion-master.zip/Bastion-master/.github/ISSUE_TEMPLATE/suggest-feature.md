---
name: Suggest Feature
about: Suggest an idea/feature for Bastion
title: "[IDEA]: "
labels: "\U0001F4A1 Idea"
assignees: ''

---

<!-- A clear and concise description of the idea you'd like to suggest. -->
